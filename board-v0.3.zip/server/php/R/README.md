### r.php - Basic principles
 * Ultra lightweight
 * Avoid array if possible
 * Make it to consume less memory
